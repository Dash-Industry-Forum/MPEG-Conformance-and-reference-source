To compile the package on POSIX systems, run "make" from this directory.

Application of interest is tslib/apps/dash_mpeg2ts_validate. It is used to validate the DASH 
media segments in MPEG-2 Transport Stream format. Detailed validation is available 
for AVC/H.264 elementary streams encapsulated in the transport stream.

Usage: 
./dash_mpeg2ts_validate [options] <input bitstream>

Options:
        -v print more info (up to two levels of extra verbosity)
        -i input MPEG-2 TS segment is an initialization segment (default: no)
        -f input MPEG-2 TS segment is the first media segment in representation (default: no)
        -h print this message and exit

Example (all content copyrights, trademarks, and other types of intellectual property belong to respective owners):

$ make
$ wget http://devimages.apple.com/iphone/samples/bipbop/gear1/fileSequence0.ts
$ tslib/apps/dash_mpeg2ts_validate -v fileSequence0.ts
